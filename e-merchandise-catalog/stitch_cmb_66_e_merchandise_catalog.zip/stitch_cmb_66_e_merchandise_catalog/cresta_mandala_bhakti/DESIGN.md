---
name: Cresta Mandala Bhakti
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#43483d'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#74796c'
  outline-variant: '#c4c8ba'
  surface-tint: '#48672f'
  primary: '#0d2300'
  on-primary: '#ffffff'
  primary-container: '#1e3a07'
  on-primary-container: '#83a567'
  inverse-primary: '#add18e'
  secondary: '#885200'
  on-secondary: '#ffffff'
  secondary-container: '#ffa533'
  on-secondary-container: '#6b3f00'
  tertiary: '#1b1f1c'
  on-tertiary: '#ffffff'
  tertiary-container: '#303431'
  on-tertiary-container: '#999c98'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c9eea8'
  primary-fixed-dim: '#add18e'
  on-primary-fixed: '#0c2000'
  on-primary-fixed-variant: '#314e1a'
  secondary-fixed: '#ffdcbc'
  secondary-fixed-dim: '#ffb86a'
  on-secondary-fixed: '#2c1700'
  on-secondary-fixed-variant: '#683d00'
  tertiary-fixed: '#e0e3df'
  tertiary-fixed-dim: '#c4c7c3'
  on-tertiary-fixed: '#191c1a'
  on-tertiary-fixed-variant: '#444844'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

The design system is engineered for a professional, vibrant e-commerce experience that balances heritage with modern efficiency. It targets a discerning audience looking for quality and reliability. The aesthetic is **Corporate Modern** with a high-end retail focus—utilizing expansive whitespace, precise alignment, and deliberate splashes of high-energy color to drive conversion.

The emotional response should be one of "Trusted Vitality." While the deep green establishes an authoritative, grounded presence, the vibrant orange accents inject energy and urgency into the shopping journey. Visuals are clean and unencumbered, prioritizing product photography and clear calls to action.

## Colors

The palette is led by **Deep Forest Green**, used for global navigation, footers, and structural identity to provide a sense of stability and premium quality. **Bright Orange** is the strategic accent color, reserved exclusively for high-priority interactions like "Checkout" and "Add to Cart" to maximize visual saliency.

Neutral tones are used for secondary text and borders, while a very pale green tint (Tertiary) provides subtle background differentiation for sections like product specifications or review blocks. The background remains pure white to ensure product imagery remains the focal point.

## Typography

This design system utilizes **Inter** across all levels to maintain a systematic, highly legible, and modern feel. Headlines use tighter letter spacing and heavier weights to command attention, while body text is optimized for readability with generous line heights.

Scale is managed via a modular hierarchy. On mobile devices, Display and Headline sizes downscale to prevent excessive wrapping, ensuring that product titles and promotional banners remain impactful without overwhelming the viewport.

## Layout & Spacing

The design system employs a **Fluid-Fixed Hybrid Grid**. Content is housed in a centered container with a maximum width of 1280px. 

- **Desktop (1024px+):** 12-column grid. Product listings use a 4 or 5 column layout depending on category density.
- **Tablet (768px - 1023px):** 8-column grid. Product listings reflow to 2 or 3 columns.
- **Mobile (Up to 767px):** 4-column grid. Product listings utilize 1 or 2 columns to maintain image clarity.

Spacing follows a strict 4px/8px baseline power-of-two scale to ensure mathematical harmony between elements.

## Elevation & Depth

This design system uses **Ambient Shadows** and **Tonal Layering** to create a sense of organized depth.

- **Level 0 (Flat):** Main background and layout structure.
- **Level 1 (Soft Shadow):** Product cards and input fields. Uses a 10% opacity black shadow with a 12px blur to suggest a subtle lift from the background.
- **Level 2 (Hover State):** When a user hovers over a product card or button, the shadow deepens (15% opacity, 20px blur) and the element scales slightly (1.02x) to provide tactile feedback.
- **Level 3 (Overlay):** Modals, carts, and toast notifications. These use a heavier shadow and a slight background backdrop-filter (blur: 4px) to isolate the interaction from the content below.

## Shapes

The shape language is defined as **Rounded**, providing an approachable and modern commercial feel.

- **Standard Elements:** Buttons, input fields, and tags use `rounded-md` (0.5rem / 8px).
- **Containers:** Product cards and promotional banners use `rounded-lg` (1rem / 16px) to soften the overall layout.
- **Interactive Circles:** Search bars and icon-only buttons may use `rounded-full` (pill-shaped) to distinguish them from primary action containers.

## Components

### Buttons
- **Primary CTA:** Bright Orange (#EF9825) with white text. High-contrast, bold weight.
- **Secondary:** Deep Forest Green (#1E3A07) with white text. Used for less urgent navigation or filters.
- **Ghost/Outline:** Deep Green border with transparent background. Used for "View More" or secondary actions.

### Cards
Product cards feature a white background, `rounded-lg` corners, and a Level 1 shadow. On hover, the card lifts (Level 2 shadow) and the secondary color appears as an "Add to Cart" button or icon.

### Inputs
Standard inputs use a subtle 1px gray border. On focus, the border transitions to Deep Forest Green with a 2px outer glow (Primary Green at 20% opacity).

### Loading & Feedback
- **Skeleton States:** Use a neutral light gray pulse for image and text placeholders during fetch.
- **Toasts:** Professional, floating notifications at the top-right. Success (Green), Error (Red), and Info (Orange) states utilize small icons and clear typography.
- **Transitions:** All hover and state changes use a `cubic-bezier(0.4, 0, 0.2, 1)` transition over 300ms for a smooth, high-end feel.